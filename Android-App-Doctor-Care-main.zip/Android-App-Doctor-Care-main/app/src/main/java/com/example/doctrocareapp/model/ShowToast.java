package com.example.doctrocareapp.model;

public interface ShowToast {

    public void onShowToast (String message);

}
