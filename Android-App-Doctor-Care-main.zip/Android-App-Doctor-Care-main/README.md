# Android-App-Doctor-Care
The college assignment create an Android application using Android Studio and Firebase<br>
A mobile-based platform for consulting with specialist doctors
